import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AppWrapper from "./context/AppWrapper";
import Nav from "./components/Nav";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Cart from "./pages/Cart";
import NotFound from "./pages/NotFound";

const App = () => {
  return (
    <BrowserRouter>
      <AppWrapper>
        <div style={{ maxWidth: 900, margin: "0 auto", padding: 12 }}>
          <Nav />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </AppWrapper>
    </BrowserRouter>
  );
};

export default App;